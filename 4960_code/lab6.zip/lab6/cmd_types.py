from enum import Enum

class CMD(Enum):
    WALL_PID = 0
    STOP = 1
    MOVE_FORWARD